package pk.cuiatd.dp.builder;

public enum Transmission {
	SINGLE_SPEED, MANUAL, AUTOMATIC, SEMI_AUTOMATIC
}
