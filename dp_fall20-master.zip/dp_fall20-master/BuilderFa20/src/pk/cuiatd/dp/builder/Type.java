package pk.cuiatd.dp.builder;

public enum Type {
	CITY_CAR, SPORTS_CAR, SUV
}
