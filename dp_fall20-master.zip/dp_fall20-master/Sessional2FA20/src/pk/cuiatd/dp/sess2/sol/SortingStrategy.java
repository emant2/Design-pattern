package pk.cuiatd.dp.sess2.sol;

public interface SortingStrategy {
	void sort(char arr[]);
}
