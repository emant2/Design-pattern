package pk.cui.sc.fm;

public abstract class Geometery {
	public abstract Shape createShape();
}
