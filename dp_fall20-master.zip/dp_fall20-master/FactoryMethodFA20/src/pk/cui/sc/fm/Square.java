package pk.cui.sc.fm;

public class Square implements Shape{

	@Override
	public void draw() {
		System.out.println("square is drawn");
		
	}
	

}
