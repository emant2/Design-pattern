package pk.cui.sc.fm;

public interface Shape {
	void draw();
}
