package pk.cui.sc.fm;

public class CricleGeometry extends Geometery{

	@Override
	public Shape createShape() {
		return new Circle();
	}

}
