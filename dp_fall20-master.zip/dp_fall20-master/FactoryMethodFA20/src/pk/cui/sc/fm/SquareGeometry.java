package pk.cui.sc.fm;

public class SquareGeometry extends Geometery{

	@Override
	public Shape createShape() {
		return new Square();
	}

}
