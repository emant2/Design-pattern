package pk.cuiatd.dp.q2;

public class NetworkServer {
	public void boot(){
		System.out.println("Network server is booting ...");
	}
	public void readSystemConfigurations(){
		System.out.println("Network server is reading the system configurations ...");
	}
	public void saveSystemConfigurations(){
		System.out.println("Network server is saving the system configurations ...");
	}
	public void shutdown(){
		System.out.println("Network server is shutting down ...");
	}
}
