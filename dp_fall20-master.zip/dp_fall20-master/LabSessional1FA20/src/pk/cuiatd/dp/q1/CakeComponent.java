package pk.cuiatd.dp.q1;

public interface CakeComponent {
	double getPrice();
	String getDescription();
}
