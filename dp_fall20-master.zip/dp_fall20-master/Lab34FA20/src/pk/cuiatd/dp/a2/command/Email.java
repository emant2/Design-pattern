package pk.cuiatd.dp.a2.command;

public class Email {
	public void sendEmail(){
		System.out.println("Sending email.......");
	}
}
