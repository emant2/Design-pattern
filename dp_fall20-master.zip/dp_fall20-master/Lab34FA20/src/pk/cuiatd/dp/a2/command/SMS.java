package pk.cuiatd.dp.a2.command;

public class SMS {
	public void sendSMS(){
		System.out.println("Sending SMS...");
	}
}
