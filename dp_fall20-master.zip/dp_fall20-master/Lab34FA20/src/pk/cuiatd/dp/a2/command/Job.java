package pk.cuiatd.dp.a2.command;

public interface Job {
	void run();
}
