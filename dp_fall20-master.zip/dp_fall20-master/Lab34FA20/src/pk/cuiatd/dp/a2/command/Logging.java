package pk.cuiatd.dp.a2.command;

public class Logging {
	public void log(){
		System.out.println("Logging...");
	}
}
