package pk.cuiatd.dp.a2.command;

public class FileIO {
	public void execute(){
		System.out.println("Executing File IO operations...");
	}
}
