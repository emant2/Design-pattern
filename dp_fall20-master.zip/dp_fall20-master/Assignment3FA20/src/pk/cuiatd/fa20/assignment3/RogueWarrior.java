package pk.cuiatd.fa20.assignment3;

public class RogueWarrior extends MemberBase {
	@Override
	public String toString() {
		return "Rogue Warrior ["+strength+"]";
	}
}
