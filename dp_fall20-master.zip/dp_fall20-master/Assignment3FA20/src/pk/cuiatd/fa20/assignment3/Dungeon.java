package pk.cuiatd.fa20.assignment3;

public interface Dungeon {
	void addMember(Member member);
	void act(Member actor, Action action);
}
