package pk.cuiatd.fa20.assignment3;

public class BarbarianViking extends MemberBase {

	@Override
	public String toString() {
		return "Barbarian Viking ["+strength+"]";
	}
}
