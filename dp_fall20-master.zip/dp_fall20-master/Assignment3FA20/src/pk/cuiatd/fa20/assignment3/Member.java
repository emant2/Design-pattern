package pk.cuiatd.fa20.assignment3;

public interface Member {
	void joinedParty(Dungeon party);
	void partyAction(Action action);
	void act(Action action);
}
