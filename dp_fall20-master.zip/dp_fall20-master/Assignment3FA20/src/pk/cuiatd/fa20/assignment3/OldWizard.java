package pk.cuiatd.fa20.assignment3;

public class OldWizard extends MemberBase {
	@Override
	public String toString() {
		return "Old Wizard ["+strength+"]";
	}
}
