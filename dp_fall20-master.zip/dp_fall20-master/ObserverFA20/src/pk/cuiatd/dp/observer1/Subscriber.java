package pk.cuiatd.dp.observer1;

public interface Subscriber {
	void update();
}
