package pk.cuiatd.dp.observer2;

public interface Subscriber {
	void update(String update);
}
