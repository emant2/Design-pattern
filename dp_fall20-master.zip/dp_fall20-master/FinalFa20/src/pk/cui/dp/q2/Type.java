package pk.cui.dp.q2;

public enum Type {
	CLASS_DIAGRAM, USE_CASE_DIAGRAM, SEQUENCE_DIAGRAM
}
