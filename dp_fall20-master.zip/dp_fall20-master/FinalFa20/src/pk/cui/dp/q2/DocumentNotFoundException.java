package pk.cui.dp.q2;

public class DocumentNotFoundException extends Exception {

	private static final long serialVersionUID = -7988628487910227540L;

	public DocumentNotFoundException(String message) {
		super(message);
	}

}
