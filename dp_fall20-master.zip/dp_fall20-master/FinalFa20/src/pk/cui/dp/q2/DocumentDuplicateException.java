package pk.cui.dp.q2;

public class DocumentDuplicateException extends Exception {

	private static final long serialVersionUID = -6578172524706252625L;

	public DocumentDuplicateException(String message) {
		super(message);
	}

}
