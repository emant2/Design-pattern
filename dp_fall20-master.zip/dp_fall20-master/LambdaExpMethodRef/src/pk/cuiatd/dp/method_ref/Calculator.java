package pk.cuiatd.dp.method_ref;

public interface Calculator {
	void squareAndPrint(int x);
}
