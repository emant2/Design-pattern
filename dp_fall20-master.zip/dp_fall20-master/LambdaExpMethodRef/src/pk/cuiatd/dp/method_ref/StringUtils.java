package pk.cuiatd.dp.method_ref;

public class StringUtils {
	public static void capitalize(String word){
		System.out.println(word.toUpperCase());
	}
}
