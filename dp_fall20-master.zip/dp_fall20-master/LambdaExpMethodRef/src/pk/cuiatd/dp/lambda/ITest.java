package pk.cuiatd.dp.lambda;

public interface ITest {
	int method();
}
