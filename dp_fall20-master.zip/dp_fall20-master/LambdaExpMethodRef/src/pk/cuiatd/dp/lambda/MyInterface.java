package pk.cuiatd.dp.lambda;

public interface MyInterface {
	void call();
}
