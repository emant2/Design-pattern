package pk.cuiatd.dp.lambda;

public interface Calculator2 {
	int square (int x);
}
