package pk.cuiatd.dp.lambda;

public interface Calculator {
	int add(int x, int y);
}
