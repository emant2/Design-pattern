package pk.cuiatd.dp.di;

public interface MessageService {
	void sendMessage(String message, String reciever);
}
