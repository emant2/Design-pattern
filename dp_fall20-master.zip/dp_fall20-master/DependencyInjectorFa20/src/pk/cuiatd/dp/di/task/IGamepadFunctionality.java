package pk.cuiatd.dp.di.task;

public interface IGamepadFunctionality {
	String getGamepadName();
    void setVibrationPower(float InPower);
}
