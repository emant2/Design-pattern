package pk.cuiatd.dp.di.task2;

public interface UserDataRepository {
	public void save(User user);
}
