package pk.cuiatd.dp.di;

public interface MessageServiceInjector {
	Client getClient();
}
