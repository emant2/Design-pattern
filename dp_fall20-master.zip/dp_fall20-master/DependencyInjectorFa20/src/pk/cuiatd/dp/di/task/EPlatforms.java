package pk.cuiatd.dp.di.task;

public enum EPlatforms {
 Xbox, Playstation, Steam
}
