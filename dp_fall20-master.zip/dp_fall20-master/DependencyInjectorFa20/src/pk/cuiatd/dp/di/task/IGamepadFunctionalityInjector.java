package pk.cuiatd.dp.di.task;

public interface IGamepadFunctionalityInjector {
	void injectFunctionality(IGamepadFunctionality InGamepadFunctionality);
}
