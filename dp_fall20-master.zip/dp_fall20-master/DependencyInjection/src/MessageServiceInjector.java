
public interface MessageServiceInjector {
	public Client getClient();
}
