
public interface MessageService {
	void sendMessage(String msg, String rec);
}
