package pk.cuiatd.dp.builder;

public enum Roast {
	Unroasted, Light, Medium, Dark
}
