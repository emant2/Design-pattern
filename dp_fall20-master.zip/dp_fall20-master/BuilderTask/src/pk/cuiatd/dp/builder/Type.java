package pk.cuiatd.dp.builder;

public enum Type {
	Espresso, Caff�Freddo
}
