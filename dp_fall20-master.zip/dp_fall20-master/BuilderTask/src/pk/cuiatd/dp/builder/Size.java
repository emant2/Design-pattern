package pk.cuiatd.dp.builder;

public enum Size {
	Single, Double
}
