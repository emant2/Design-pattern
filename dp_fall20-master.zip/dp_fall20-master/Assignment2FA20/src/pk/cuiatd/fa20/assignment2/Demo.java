package pk.cuiatd.fa20.assignment2;


public class Demo {

	public static void main(String[] args) {
		KitchenOperator.getInstance().init(); 
		
		KitchenOperator.getInstance().finish();
	}

}
