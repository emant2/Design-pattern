package pk.cuiatd.fa20.assignment2;

public interface Command {
	void execute();
}
