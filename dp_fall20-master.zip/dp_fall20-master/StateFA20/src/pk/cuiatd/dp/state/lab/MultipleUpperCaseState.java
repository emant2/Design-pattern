package pk.cuiatd.dp.state.lab;

public class MultipleUpperCaseState implements State {

	/* Counter local to this state */
	private int count = 0;

	@Override
	public void writeName(Context context, String name) {
		System.out.println(name.toUpperCase());
		/* Change state after StateMultipleUpperCase's writeName() gets invoked twice */
		if (++count > 1) {
			context.setState(new LowerCaseState());
		}
	}

}
