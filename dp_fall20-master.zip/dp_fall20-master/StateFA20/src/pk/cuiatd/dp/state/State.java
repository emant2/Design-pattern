package pk.cuiatd.dp.state;

public interface State {
	void doAction();
}
