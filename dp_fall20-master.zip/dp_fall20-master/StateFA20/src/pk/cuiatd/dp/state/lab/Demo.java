package pk.cuiatd.dp.state.lab;

public class Demo {

	public static void main(String[] args) {
		Context context = new Context();

        context.writeName("Monday");
        context.writeName("Tuesday");
        context.writeName("Wednesday");
        context.writeName("Thursday");
        context.writeName("Friday");
        context.writeName("Saturday");
        context.writeName("Sunday");

	}

}
