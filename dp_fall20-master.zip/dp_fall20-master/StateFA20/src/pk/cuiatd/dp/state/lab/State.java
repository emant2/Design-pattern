package pk.cuiatd.dp.state.lab;

public interface State {
	void writeName(Context context, String name);
}
