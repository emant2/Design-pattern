package pk.cuiatd.dp.template;

public class DatabaseParser extends DataParser{

	@Override
	protected void readData() {
		System.out.println("Reading data from the Database");
		
	}

	/*
	@Override
	protected void processData() {
		System.out.println("Processing Database data");
		
	}*/

	/*
	@Override
	protected void writeData() {
		System.out.println("Writing Database data");
		
	}*/
}
