package pk.cuiatd.dp.template;

public class CSVDataParser extends DataParser{

	@Override
	protected void readData() {
		System.out.println("Reading data from a CSV file");
		
	}

	/*
	@Override
	protected void processData() {
		System.out.println("Processing CSV data");
		
	}*/

	@Override
	protected void writeData() {
		System.out.println("Writing CSV data");
		
	}

}
