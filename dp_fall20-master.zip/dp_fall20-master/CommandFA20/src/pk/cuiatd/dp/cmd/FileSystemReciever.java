package pk.cuiatd.dp.cmd;

public interface FileSystemReciever {
	void openFile();
	void closeFile();
	void writeFile();

}
