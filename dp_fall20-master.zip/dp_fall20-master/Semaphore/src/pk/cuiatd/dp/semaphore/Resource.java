package pk.cuiatd.dp.semaphore;

public class Resource {
	static int count = 0; 
}
