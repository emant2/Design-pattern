package pk.cuiatd.dp.afactory;

public interface GUIFactory {
	Button createButton();
	Checkbox createCheckbox();
}
