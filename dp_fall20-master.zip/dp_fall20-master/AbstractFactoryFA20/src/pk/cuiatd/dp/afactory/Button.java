package pk.cuiatd.dp.afactory;

public interface Button {
	void paint();
}
