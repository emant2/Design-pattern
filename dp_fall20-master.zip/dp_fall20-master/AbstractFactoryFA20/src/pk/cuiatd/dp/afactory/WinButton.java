package pk.cuiatd.dp.afactory;

public class WinButton implements Button{

	@Override
	public void paint() {
		System.out.println("Windows button is painted");
		
	}

}
