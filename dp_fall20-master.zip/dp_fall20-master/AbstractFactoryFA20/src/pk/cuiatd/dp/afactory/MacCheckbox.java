package pk.cuiatd.dp.afactory;

public class MacCheckbox implements Checkbox{

	@Override
	public void paint() {
		System.out.println("Mac chekbox is painted");
		
	}

}
