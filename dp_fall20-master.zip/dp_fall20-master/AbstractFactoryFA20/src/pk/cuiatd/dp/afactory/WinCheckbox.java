package pk.cuiatd.dp.afactory;

public class WinCheckbox implements Checkbox{

	@Override
	public void paint() {
		System.out.println("Windows checkbox is painted");
		
	}

}