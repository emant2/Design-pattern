package pk.cuiatd.dp.afactory;

public interface Checkbox {
	void paint();
}
