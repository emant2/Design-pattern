package pk.cuiatd.dp.afactory;

public class MacButton implements Button{

	@Override
	public void paint() {
		System.out.println("Mac button is painted");
		
	}

}
