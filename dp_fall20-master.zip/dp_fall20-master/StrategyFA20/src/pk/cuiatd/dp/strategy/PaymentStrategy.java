package pk.cuiatd.dp.strategy;

public interface PaymentStrategy {
	void pay(int amount);
}
