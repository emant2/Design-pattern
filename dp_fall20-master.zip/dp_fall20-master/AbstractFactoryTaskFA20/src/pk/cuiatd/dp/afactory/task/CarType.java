package pk.cuiatd.dp.afactory.task;

public enum CarType {
	MINI, LUXURY 
}
