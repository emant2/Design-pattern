package pk.cuiatd.dp.afactory.task;

public interface CarFactory {
	Car createMiniCar();
	Car createLuxuryCar();
}
