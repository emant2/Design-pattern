package pk.cuiatd.dp.it;

public interface TV {
	Iterator getIterator();
}
