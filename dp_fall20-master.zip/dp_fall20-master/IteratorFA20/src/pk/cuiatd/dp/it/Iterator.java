package pk.cuiatd.dp.it;

public interface Iterator {
	boolean hasMore();
	String getNext();
}
