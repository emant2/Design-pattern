package pk.cuiatd.dp.proxy;

public interface Image {
	void display();
	String getFileName();
}
