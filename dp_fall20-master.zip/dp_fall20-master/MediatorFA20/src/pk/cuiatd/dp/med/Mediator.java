package pk.cuiatd.dp.med;

public interface Mediator {
	void notify(Object sender, String event);
}
