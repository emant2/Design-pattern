package pk.cuiatd.dp.access;

public interface Prototype {
	AccessControl clone();
}
