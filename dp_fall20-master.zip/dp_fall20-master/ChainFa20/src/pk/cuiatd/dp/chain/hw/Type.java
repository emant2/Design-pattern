package pk.cuiatd.dp.chain.hw;

public enum Type {
	TXT, DOC, PDF, MP3, GIF
}
